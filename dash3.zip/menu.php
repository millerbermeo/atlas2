<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
  <!--left-fixed -navigation-->
  <aside class="sidebar-left">
    <nav class="navbar navbar-inverse">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          </button>
          <h1><a class="navbar-brand" href="index.php"><img src="images/issabel_logo_mini2.png" width="70%" alt="auto"></a></h1>

        </div>
        <!-- <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="sidebar-menu">
            <li class="header">MENÚ DE NAVEGACIÓN</li>
            <li class="treeview">
              <a href="help.php">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview">
                    <a href="#">
                    <i class="fa fa-pie-chart"></i>
                    <span>Reportes</span>
                    <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="help.php"><i class="fa fa-angle-right"></i> Reporte de llamadas</a></li>
                      <li><a href="help.php"><i class="fa fa-angle-right"></i> Reporte de recesos</a></li>
                      <li><a href="help.php"><i class="fa fa-angle-right"></i> Reporte de campañas</a></li>

                    </ul>
            </li>
            <li class="treeview">
                    <a href="#">
                    <i class="fa fa-laptop"></i>
                    <span>Usuarios</span>
                    <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="help.php"><i class="fa fa-angle-right"></i> Listar Usuarios</a></li>
                      <li><a href="help.php"><i class="fa fa-angle-right"></i> Crear Usuario</a></li>
                    </ul>
            </li>

            <li class="header">EXTRAS</li>
            <li><a href="help.php"><i class="fa fa-angle-right text-red"></i> <span>Ayuda</span></a></li>
            <li><a href="vDashboard.php"><i class="fa fa-angle-right text-red"></i> <span>Versión Dashboard</span></a></li>

          </ul>
        </div> -->
        <!-- /.navbar-collapse -->

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="sidebar-menu">
            <li class="header">MENÚ DE NAVEGACIÓN</li>
            <li class="treeview">
              <a href="index.php">
              <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview">
                    <a href="#">
                    <i class="fa fa-pie-chart"></i>
                    <span>Reportes</span>
                    <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="report.php"><i class="fa fa-angle-right"></i> Reporte de llamadas</a></li>
                      <!-- <li><a href="report2.php"><i class="fa fa-angle-right"></i> Reporte de llamadas Agente Virtual</a></li> -->
                      <li><a href="report_recesos.php"><i class="fa fa-angle-right"></i> Reporte de recesos</a></li>
                      <li><a href="report_campañas.php"><i class="fa fa-angle-right"></i> Reporte de campañas</a></li>

                    </ul>
            </li>
            <li class="treeview">
                    <a href="#">
                    <i class="fa fa-laptop"></i>
                    <span>Usuarios</span>
                    <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="users.php"><i class="fa fa-angle-right"></i> Listar Agentes</a></li>
                      <!-- <li><a href="createuser.php"><i class="fa fa-angle-right"></i> Crear Usuario</a></li> -->
                    </ul>
            </li>

            <li class="header">EXTRAS</li>
            <li><a href="help.php"><i class="fa fa-angle-right text-red"></i> <span>Ayuda</span></a></li>
            <li><a href="vDashboard.php"><i class="fa fa-angle-right text-red"></i> <span>Versión Dashboard</span></a></li>

          </ul>
        </div>

        <!-- aqui -->


    </nav>
  </aside>
</div>
